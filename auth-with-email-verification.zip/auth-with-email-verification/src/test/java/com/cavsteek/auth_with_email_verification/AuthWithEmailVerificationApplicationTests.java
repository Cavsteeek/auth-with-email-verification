package com.cavsteek.auth_with_email_verification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthWithEmailVerificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
